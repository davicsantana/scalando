package br.com.scalando.flickr

object ClienteFlickr extends App{


//  val secret = "4682f5607dcd714f"
//  val method = "flickr.photos.search"
//  val tags = "scala"
//  val url = s"https://api.flickr.com/services/rest/?method=$method&api_key=$apiKey&tags=$tags"
//  println(url)
//  scala.io.Source.fromURL(url).getLines().foreach(println)
//
//  def usuarioAtual() = usuaoOpt match {
//    case Some(usuario) => usuario
//    case None => "anônimo"
//  }

  val foto1 = new Foto(1, "jcranky", "uma foto do jcranky", 1)
  val foto2 = new Foto(2, "jcranky", "outra foto do jcranky", 1)
  val foto3 = new Foto(3, "jcranky", "mais uma foto do jcranky", 1)
  val fotos = Set(foto1, foto2, foto3, foto1)
  val lFotos = Nil.::(foto1).::(foto3).::(foto2).::(foto1)
  val wFotos = foto1 :: foto2 :: foto3 :: foto1 :: Nil

  
}
