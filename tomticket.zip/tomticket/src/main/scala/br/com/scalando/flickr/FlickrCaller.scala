package br.com.scalando.flickr

class FlickrCaller(val apiKey: String) {
  val apiKe:String = "a6a4133e4f172f7d509db6db966e635e"

  def buscaFotos(tag: String = "", userId: String = ""): Seq[Foto] = {
    return ???
  }


}
