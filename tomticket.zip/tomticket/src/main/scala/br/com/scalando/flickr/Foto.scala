package br.com.scalando.flickr

class Foto(val id: Long, val owner: String, val title: String, val farm: Int)
