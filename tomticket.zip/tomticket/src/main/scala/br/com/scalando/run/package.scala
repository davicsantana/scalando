package br.com.scalando

import java.io.IOException
import br.com.scalando.flickr.FlickrCaller
import scala.util.control.NonFatal

package object run {

  try {
    val busca = new FlickrCaller("")
    busca.buscaFotos()
  }
  catch {

    case e: IOException => println("exceção de IO")
    case e: Exception => println("exceção indefinida")
    case NonFatal(t) => println("outra exceção")

  }
}
