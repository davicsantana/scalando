
object Solution extends App {


}
