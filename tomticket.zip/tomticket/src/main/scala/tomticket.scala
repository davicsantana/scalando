import org.apache.spark.sql.SparkSession


object Tomtick extends App {



//  val url = "https://api.tomticket.com/chamados/85f7f771eebf4a6b6922a5519f667a53/1"
//  val json = scala.io.Source.fromURL(url).mkString

//  println(json)
//  val spark = SparkSession.builder().appName("Tomticket").master("local[*]").getOrCreate()
//  val rddJson = spark.sparkContext.parallelize(List(json))
//  val tree = spark.read.json(url).select("data.atendente","data.categoria")

//    tree.createOrReplaceTempView("tomticket")
//  tree.show
//  tree.printSchema()
//  println(tree)
//    spark.sql("select data.* from tomticket")

}
